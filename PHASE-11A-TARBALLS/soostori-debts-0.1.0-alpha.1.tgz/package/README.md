# @soostori/debts

Debt/credit domain. Non-stock — runs offline without Primary Device coordination.

## Events

- `debt.created`
- `debt.payment_recorded` (emits with payment amount)
- `debt.payment_reminder`
- `debt.written_off`
